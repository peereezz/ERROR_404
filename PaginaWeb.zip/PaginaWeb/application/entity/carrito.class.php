<?php 
class Carrito {
    
    private $listaProductos; //array de objetos de tiop producto

    private $id;
    private $id_carrito;
    private $id_producto;
    private $nombre;
    private $precio;
    private $cantidad;

    //public function addProducto($producto) {
    //   array_push($listaProductos, $producto);
    //}
    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getListaProductos()
    {
        return $this->listaProductos;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @param mixed $listaProductos
     */
    public function setListaProductos($listaProductos)
    {
        $this->listaProductos = $listaProductos;
    }

    /**
     * Get the value of nombre
     */ 
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * Set the value of nombre
     *
     * @return  self
     */ 
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;

        return $this;
    }

    /**
     * Get the value of precio
     */ 
    public function getPrecio()
    {
        return $this->precio;
    }

    /**
     * Set the value of precio
     *
     * @return  self
     */ 
    public function setPrecio($precio)
    {
        $this->precio = $precio;

        return $this;
    }

    /**
     * Get the value of cantidad
     */ 
    public function getCantidad()
    {
        return $this->cantidad;
    }

    /**
     * Set the value of cantidad
     *
     * @return  self
     */ 
    public function setCantidad($cantidad)
    {
        $this->cantidad = $cantidad;

        return $this;
    }

    /**
     * Get the value of id_producto
     */ 
    public function getId_producto()
    {
        return $this->id_producto;
    }

    /**
     * Set the value of id_producto
     *
     * @return  self
     */ 
    public function setId_producto($id_producto)
    {
        $this->id_producto = $id_producto;

        return $this;
    }

    /**
     * Get the value of id_carrito
     */ 
    public function getId_carrito()
    {
        return $this->id_carrito;
    }

    /**
     * Set the value of id_carrito
     *
     * @return  self
     */ 
    public function setId_carrito($id_carrito)
    {
        $this->id_carrito = $id_carrito;

        return $this;
    }
}
?>