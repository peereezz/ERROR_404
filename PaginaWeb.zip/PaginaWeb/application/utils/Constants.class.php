<?php
class Constants {
	public static $ROL_USUARIO = 0;
	public static $ROL_ADMIN = 1;
}