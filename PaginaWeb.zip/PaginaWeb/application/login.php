<?php 
    include_once 'persistente/MySQLPDO.class.php';
    include_once 'entity/usuario.class.php';
    include_once '../Web/PaginaWeb/application/pages/inicio.php';

    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="estilos2.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <title>Error Sports</title>
</head>
<body>
    <div class="menu">
        <h1>Error Sports</h1>
        <ul>
            <li><a href="login.php">Iniciar Sesion</a></li>
            <li><a href="pages/registrarse.php">Registrarse</a></li>
        </ul>
        <a href="login.php"><img class="minilogin" src="img/cuenta1.png" alt=""></a>
    </div>
    <div>
        <form class="login" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <h2>Inicio Sesion</h2>
            <input class="boton" type="text" name="usuario" placeholder="Usuario" required><br><br>
            <input class="boton" type="password" name="password" placeholder="Contraseña" required><br><br>
            <input class="boton" type="submit" value="Iniciar Sesion" name="btn_login"><br>
            <?php
            if (isset($_POST['btn_login'])) {
        
                $usuario = $_POST['usuario'];
                $password = $_POST['password'];
                
                MySQLPDO::connect();
                $loginUsuario = MySQLPDO::loginusu($usuario, $password);
                
                if ($loginUsuario != null) {
                    $_SESSION['usuario'] = $loginUsuario;
                    header("Location: pages/inicio.php");
                } else {
                    ?>
                        <p class="plogin">ERROR usuario o contraseña incorrectos</p>
                        <a href="pages/he_olvidado.php"><button class="boton">He olvidado mi contraseña</button></a>
                    <?php
                }
            }
            ?>
        </form>
    </div>
</body>
</html>
