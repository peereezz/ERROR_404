<?php
    include_once '../persistente/MySQLPDO.class.php';
    $id = $_POST['id'];
    MySQLPDO::connect();
    $resultado = MySQLPDO::borrarusuario($id);
    if ($resultado != 0){
        header("location: lista_usuarios.php");
        exit();
    } else {
        echo "El usuario no se ha borrado";
    }
?>