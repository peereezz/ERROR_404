<?php 
    include_once '../persistente/MySQLPDO.class.php';
    include_once '../utils/Constants.class.php';
    if (isset($_GET['id_producto'])){
        $id_producto = $_GET['id_producto'];
    } else if (isset($_POST['id_producto'])) {
        $id_producto = $_POST['id_producto'];
    } else {
        die ("ERROR: Se ha detectado un error en el sistema");
    }
    MySQLPDO::connect();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@500;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="../estilosweb/estilos2.css">
        <title>Error Sports</title>
    </head>
    <body>
        <div class="menu">
            <a href="inicio.php"><h1>Error Sports</h1></a>
            <ul>
                <li><a href="inicio.php">Inicio</a></li>
                <li><a href="lista_producto.php">Productos</a></li>
                <li><a href="lista_usuarios.php">Usuarios</a></li>
                <li><a href="alta_producto.php">Alta de Producto</a></li>
            </ul>
            <a href="../login.php"><img class="minilogin" src="../img/cuenta2.png" alt=""></a>
        </div>
        <div>
        <?php
            $resultado = null;
            
            $producto = MySQLPDO::opProducto($id_producto);
            if($producto != null){

        
        ?>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <input type="hidden" name="id_producto" value="<?php echo $producto->getId_producto(); ?>"><br><br>
            <input class="boton" type="text" name="nombre" value="<?php echo $producto->getNombre();?>"><br><br>
            <input class="boton" type="text" name="descripcion" value="<?php echo $producto->getDescripcion(); ?>"><br><br>
            <input class="boton" type="number" name="cantidad" value="<?php echo $producto->getCantidad(); ?>"><br><br>
            <input class="boton" type="decimal" name="precio" value="<?php echo $producto->getPrecio(); ?>"><br><br>
            <input class="boton" type="submit" name="btn_modificar" value="Modificar">
        </form>
        <?php 
            if (isset($_POST['btn_modificar'])){

                $nombre = $_POST['nombre'];
                $descripcion = $_POST['descripcion'];
                $cantidad = $_POST['cantidad'];
                $precio = $_POST['precio'];
                $id_producto = $_POST['id_producto'];

                $producto = new producto();

                $producto->setNombre($nombre);
                $producto->setDescripcion($descripcion);
                $producto->setCantidad($cantidad);
                $producto->setPrecio($precio);
                $producto->setId_producto($id_producto);

                $resultado = MySQLPDO::modificarProducto($producto);
                
                if ($resultado != 0) {
                    header("location: lista_producto.php");
                    exit();
                } else {
                    ?><p>ERROR: No se ha podido modificar</p><?php
                }
            }
        } else {
            echo "ERROR: El producto que deseas modificar no existe";
        }
        ?>
        </div>
    </body>
</html>
