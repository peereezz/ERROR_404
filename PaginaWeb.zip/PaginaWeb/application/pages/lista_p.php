<?php 
include_once '../persistente/MySQLPDO.class.php';
    $id_producto = $_POST['id_producto'];

    MySQLPDO::connect();
    $resultado = MySQLPDO::productoBorrar($id_producto);

    if ($resultado != 0){
        header("location: lista_producto.php");
        exit();
    } else {
        echo "ERROR";
    }
?>