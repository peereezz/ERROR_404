<?php 
    include_once '../persistente/MySQLPDO.class.php';
    include_once '../entity/usuario.class.php';

    $id = $_POST['id'];
    $pass = $_POST['pass'];

    $cliente = new Clientes;

    $cliente->setId($id);
    $cliente->setPassword($pass);

    MySQLPDO::connect();

    $res = MySQLPDO::modiPass($cliente);

    if ($res != 0){
        header('Location: ../login.php');
    } else {
        echo 'error de mod';
    }

?>