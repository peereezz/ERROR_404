<?php
include_once '../persistente/MySQLPDO.class.php';
include_once '../entity/usuario.class.php';
include_once '../utils/Constants.class.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../estilosweb/estilos2.css">
    <title>Error Sports</title>
</head>
<body>
    <?php 
        session_start();
        $loginUsuario = $_SESSION['usuario'];
        $rol = $loginUsuario->getRol();
    ?>
    <div class="menu">
        <a href="inicio.php"><h1>Error Sports</h1></a>
        <ul>
            <li><a href="inicio.php">Inicio</a></li>
            <li><a href="lista_producto.php">Productos</a></li>
            <?php 
            	if ($rol == Constants::$ROL_ADMIN){
            ?>
            <li><a href="lista_usuarios.php">Usuarios</a></li>
            <li><a href="alta_producto.php">Alta de Producto</a></li>
            <?php 
                }
            ?>
        </ul>
        <a href="../login.php"><img class="minilogin" src="../img/cuenta2.png" alt=""></a>
    </div>
    <img class="imgLogo" src="../img/logoError.jpg" alt="">
    <h2>Quiénes somos</h2>
    <p>ERROR SPORT es una empresa dedicada a la venta de artículos de ping pong. 
        Nuestra esencia nace de una idea sencilla: acercar productos fiables, 
        duraderos y bien seleccionados a todas las personas que aman el tenis de mesa.
        Desde palas y pelotas hasta equipamiento para entrenamientos, 
        nuestro catálogo está pensado para acompañar tanto a quienes están dando sus primeros pasos como a jugadores que buscan un nivel más exigente.</p>
    <h2>Nuestra historia</h2>
    <p>ERROR SPORT surgió a partir de un pequeño grupo de aficionados al ping pong que, 
        tras años compitiendo en torneos locales, se dieron cuenta de que encontrar buen material no siempre era fácil. 
        Había productos excelentes, pero dispersos; marcas prometedoras, pero difíciles de conseguir; consejos valiosos, 
        pero sin un lugar donde reunirse.</p>
    <h2>Dónde estamos</h2>
    <p>Actualmente operamos desde España a través de nuestra tienda online. 
        Nuestro sistema de distribución permite enviar pedidos a cualquier punto del país, 
        centrando nuestros esfuerzos en rapidez, atención al cliente y transparencia en cada compra.</p>
</body>
</html>
