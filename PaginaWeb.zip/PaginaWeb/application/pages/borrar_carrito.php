<?php
    include_once '../persistente/MySQLPDO.class.php';
    $id = $_POST['id_carrito'];
    MySQLPDO::connect();
    $resultado = MySQLPDO::borrarcarrito($id);
    if ($resultado != 0){
        header("location: carrito.php");
    } else {
        echo "Producto no borrado";
    }
?>