<?php 
    include_once '../persistente/MySQLPDO.class.php';
    include_once '../entity/usuario.class.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../estilos2.css">
    <title>Error Sports</title>
</head>
<body>
    <div class="menu"> 
        <h1>Error Sports</h1>
        <ul>
            <li><a href="../login.php">Iniciar Sesion</a></li>
            <li><a href="registrarse.php">Registrarse</a></li>
            <li><a href="contrasena_admin.php">Administrador</a></li>
        </ul>
        <a href="../login.php"><img class="minilogin" src="../img/cuenta1.png" alt=""></a>
    </div>
    <div>
        <form method="post">
            <h2>Recuperar contraseña</h2>
            <input class="boton" type="text" name="usuario" placeholder="Usuario"><br><br>
            <input class="boton" type="submit" name="btn_usu" value="Cambiar">
        </form>
        <?php
            if (isset($_POST['btn_usu'])){
                $usu = $_POST['usuario'];
                MySQLPDO::connect();
                $cliente = MySQLPDO::opUsuario($usu);
                if($cliente != null){
        ?>
                <form method="post" action="olvi.php">
                    <input type="hidden" name="id" value="<?php echo $cliente->getId(); ?>">
                    <input class="boton" type="text" name="pass" placeholder="Contraseña Nueva"><br><br>
                    <input class="boton" type="submit" name="btn_modi" value="Modificar">
                </form>
        <?php
                    
                } else {
                    echo "Error";
                }
            } 
        ?>
    </div>
</body>
</html>