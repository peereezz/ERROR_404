<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../estilosweb/estilos2.css">
    <title>Error Sports</title>
</head>
<body>
    <div class="menu"> 
        <h1>Error Sports</h1>
        <ul>
            <li><a href="../login.php">Iniciar Sesion</a></li>
            <li><a href="registrarse.php">Registrarse</a></li>
        </ul>
        <a href="../login.php"><img class="minilogin" src="../img/cuenta1.png" alt=""></a>
    </div>
    <div>
        <form method="post" action="regis.php">
            <h2>Registrarse</h2>
            <input class="boton" type="text" name="nombre" placeholder="Nombre" required><br><br>
            <input class="boton" type="text" name="apellido" placeholder="Apellido" required><br><br>
            <input class="boton" type="email" name="email" placeholder="Email" required><br><br>
            <input class="boton" type="number" name="telefono" placeholder="Telefono" required><br><br>
            <input class="boton" type="text" name="direccion" placeholder="Direccion" required><br><br>
            <input class="boton" type="text" name="usuario" placeholder="Usuario" required><br><br>
            <input class="boton" type="password" name="contraseña" placeholder="Contraseña" required><br><br>
            <input type="hidden" name="rol" value="0">
            <input class="boton" type="submit" value="Registrarse">
        </form>
    </div>
</body>
</html>
