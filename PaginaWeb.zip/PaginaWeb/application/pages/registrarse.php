<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../estilos/estilos.css">
    <title>Error Sports</title>
</head>
<body>
    <div class="menu">
        <a href="inicio.php"><h1>Error Sports</h1></a>
        <ul>
            <li><a href="inicio.php">Inicio</a></li>
            <li><a href=""></a></li>
        </ul>
        <a href="login.php"><img class="minilogin" src="../img/cuenta1.png" alt=""></a>
    </div>
    <div>
        <form method="post" action="regis.php">
            <input class="boton" type="text" name="nombre" placeholder="Nombre" required><br><br>
            <input class="boton" type="text" name="apellido" placeholder="Apellido" required><br><br>
            <input class="boton" type="email" name="email" placeholder="Email" required><br><br>
            <input class="boton" type="text" name="telefono" placeholder="Telefono" required><br><br>
            <input class="boton" type="text" name="direccion" placeholder="Direccion" required><br><br>
            <input class="boton" type="text" name="usuario" placeholder="Usuario" required><br><br>
            <input class="boton" type="password" name="contraseña" placeholder="Contraseña" required><br><br>
            <input class="boton" type="submit" value="Registrarse">
        </form>
        
    </div>
</body>
</html>