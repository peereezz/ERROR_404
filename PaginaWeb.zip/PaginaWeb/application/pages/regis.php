<?php 
    include_once '../entity/usuario.class.php';
    include_once '../persistente/MySQLPDO.class.php';

    $nombre = $_POST["nombre"];
    $apellido = $_POST["apellido"];
    $email = $_POST["email"];
    $telefono = $_POST["telefono"];
    $direccion = $_POST["direccion"];
    $usuario = $_POST["usuario"];
    $password = $_POST["contraseña"];

    $clientes = new clientes();

    $clientes->setNombre(nombre: $nombre);
    $clientes->setApellido(apellido: $apellido);
    $clientes->setEmail(email: $email);
    $clientes->setTelefono(telefono: $telefono);
    $clientes->setDireccion(direccion: $direccion);
    $clientes->setUsuario(usuario: $usuario);
    $clientes->setPassword(password: $password);

    MySQLPDO::connect();

    $resul = MySQLPDO::registrarCliente($clientes);

    if ($resul != 0){
        header("location: login.php?registrado=true");
        exit();
    } else {
        echo "No se a podido registrar";
    }


?>