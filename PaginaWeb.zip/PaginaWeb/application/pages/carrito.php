<?php
include_once '../persistente/MySQLPDO.class.php';
include_once '../entity/usuario.class.php';
include_once '../utils/Constants.class.php';
include_once '../entity/carrito.class.php';
session_start();
    $loginUsuario = $_SESSION['usuario'];
    $rol = $loginUsuario->getRol();
?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../estilos2.css">
    <title>Error Sports</title>
</head>
<body>
    <div class="menu">
        <a href="inicio.php"><h1>Error Sports</h1></a>
        <ul>
            <li><a href="inicio.php">Inicio</a></li>
            <li><a href="lista_producto.php">Productos</a></li>
            <li><a href="carrito.php">Carrito</a></li>
            <?php if ($rol == Constants::$ROL_ADMIN){ ?>
            <li><a href="lista_usuarios.php">Usuarios</a></li>
            <li><a href="alta_producto.php">Alta de Producto</a></li>
            <?php } ?>
        </ul>
        <a href="../login.php"><img class="minilogin" src="../img/cuenta2.png" alt=""></a>
    </div>
    <div>
        <h2>Carrito</h2>
        <?php
        $id = $loginUsuario->getId();
        MySQLPDO::connect();
        $resul = MySQLPDO::busCarrito($id);
        if (sizeof($resul)!= null){
        ?>
        <table>
            <thead>
                <tr>
                    <th>Producto</th>
                    <th>Cantidad</th>
                    <th>Precio</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php 
                    $total = 0;
                    foreach ($resul as $carro){
                    $precio = $carro->getPrecio();
                    $cantidad = $carro->getCantidad();

                    $subtotal = $precio * $cantidad;
                    $total += $subtotal;
                ?>
                <tr>
                    <td><?php echo $carro->getNombre(); ?></td>
                    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                    <td>
                        <input type="hidden" name="id_carrito" value="<?php echo $carro->getId_carrito();?>">
                        <input class="boton" type="submit" name="btn_resta" value="-">
                        <?php echo $carro->getCantidad(); ?>
                        <input class="boton" type="submit" name="btn_suma" value="+">

                    </td>
                    </form>
                    <td><?php echo $preci = $carro->getPrecio(); ?> €</td>
                    <form action="borrar_carrito.php" method="post">
                    <td>
                        <input type="hidden" name="id_carrito" value="<?php echo $carro->getId_carrito();?>"/>
                        <input class="boton" type="submit" name="btn_borrar" value="Eliminar">
                    </td>
                    </form>
                </tr>
                <?php 
                    }
                ?>
                <tr>
                    <td colspan="2">Total:</td>
                    <td><?php echo $total;?> €</td>
                    <form method="post" action="vaciar_carrito.php">
                    <td>
                        <input type="hidden" name="id_cliente" value="<?php echo $loginUsuario->getId(); ?>">
                        <input class="boton" type="submit" value="Borrar todo">
                    </td>
                    </form>
                </tr>
            </tbody>
        </table>
        <?php
            if (isset($_POST['btn_suma'])){

                $id_carrito = $_POST['id_carrito'];
                $res = MySQLPDO::sumaCanti($id_carrito);

                if ($res != 0) {
                    header("location: carrito.php");
                } else {
                    ?><p>ERROR: No se ha podido modificar</p><?php
                }
            }
            if (isset($_POST['btn_resta'])){

                $id_carrito = $_POST['id_carrito'];
                $res = MySQLPDO::restaCanti($id_carrito);

                if ($res != 0) {
                    header("location: carrito.php");
                } else {
                    ?><p>No se puede modificar a menos que 0</p><?php
                }
            }
        ?>
        <form class="tramitarpedido" method="post" action="tramitar_pedido.php">
            <input class="boton" type="submit" value="Tramitar Pedido">
        </form>
        <?php 
        } else {
            ?>
                <p class="pinicio">No hay nada en el carrito</p>
                <p class="pinicio">Dirigete a la pagina de productos para agragar un producto al carrito.</p>
            <?php
        }
        ?>
        
    </div>
</body>