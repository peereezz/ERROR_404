<?php 
    include_once '../persistente/MySQLPDO.class.php';
    include_once '../entity/producto.class.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../estilosweb/estilos.css">
    <title>Error Sports</title>
</head>
<body>
    <div class="menu">
        <h1>Error Sports</h1>
        <ul>
            <li><a href="lista_usuarios.php">Lista de Usuarios</a></li>
            <li><a href="alta_producto.php">Alta de Producto</a></li>
            <li><a href="lista_producto.php">Productos</a></li>
        </ul>
        <a href="login.php"><img class="minilogin" src="../img/cuenta1.png" alt=""></a>
    </div>
    
    <div>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <input class="boton" type="text" name="nombre" placeholder="Buscar...">
            <input class="boton" type="submit" name="btn_buscar" value="Buscar">
        </form>
        <?php 
            if (isset($_POST['btn_buscar'])){
            $nombre = $_POST['nombre'];
            MySQLPDO::connect();
            $resultado = MySQLPDO::listaPrpducto($nombre);
            if (sizeof($resultado) != 0){
        ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Descripcion</th>
                    <th>Cantidad</th>
                    <th>Precio</th>
                    <th>Borrar</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                    foreach ($resultado as $producto){
                ?>
                <tr>
                    <td><?php echo $producto->getId_producto(); ?></td>
                    <td><?php echo $producto->getNombre(); ?></td>
                    <td><?php echo $producto->getDescripcion(); ?></td>
                    <td><?php echo $producto->getCantidad(); ?></td>
                    <td><?php echo $producto->getPrecio(); ?></td>
                </tr>
                <?php 
                }
                ?>
            </tbody>
        </table>
    <?php 
        } else {
            ?><h2>No ha encontrado nada el buscador</h2><?php
        }
    }
    ?>
    </div>
</body>
</html>