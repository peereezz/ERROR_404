<?php
include_once '../persistente/MySQLPDO.class.php';
include_once '../entity/usuario.class.php';
include_once '../utils/Constants.class.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../estilosweb/estilos2.css">
    <title>Error Sports</title>
</head>
<body>
<?php 
        session_start();
        $loginUsuario = $_SESSION['usuario'];
        $rol = $loginUsuario->getRol();
    ?>
    <div class="menu">
        <a href="inicio.php"><h1>Error Sports</h1></a>
        <ul>
            <li><a href="inicio.php">Inicio</a></li>
            <li><a href="lista_producto.php">Productos</a></li>
            <?php 
            	if ($rol == Constants::$ROL_ADMIN){
            ?>
            <li><a href="lista_usuarios.php">Usuarios</a></li>
            <li><a href="alta_producto.php">Alta de Producto</a></li>
            <?php 
                }
            ?>
        </ul>
        <a href="../login.php"><img class="minilogin" src="../img/cuenta2.png" alt=""></a>
    </div>
    <div>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <input class="boton" type="text" name="nombre" placeholder="Buscar...">
            <input class="boton" type="submit" name="btn_buscar" value="Buscar">
        </form>
        <?php 
            if (isset($_POST['btn_buscar'])){
            $nombre = $_POST['nombre'];
            MySQLPDO::connect();
            $resultado = MySQLPDO::listaPrpducto($nombre);
            if (sizeof($resultado) != 0){
        ?>
        <table>
            <thead>
                <tr>
                    <?php if ($rol == Constants::$ROL_ADMIN){ ?>
                    <th>ID</th>
                    <?php } ?>
                    <th>Nombre</th>
                    <th>Descripcion</th>
                    <?php if ($rol == Constants::$ROL_ADMIN){ ?>
                    <th>Cantidad</th>
                    <?php } ?>
                    <th>Precio</th>
                    <?php if ($rol == Constants::$ROL_ADMIN){ ?>
                    <th>Borrar</th>
                    <?php } ?>
                    <?php if ($rol == Constants::$ROL_USUARIO){ ?>
                    <th>Comprar</th>
                    <?php } ?>
                </tr>
            </thead>
            <tbody>
                <?php 
                    foreach ($resultado as $producto){
                ?>
                <tr>
                    <?php if ($rol == Constants::$ROL_ADMIN){ ?>
                    <td><a href="modificar_producto.php?id_producto=<?php echo $producto->getId_producto(); ?>"><?php echo $producto->getId_producto(); ?></a></td>
                    <?php } ?>
                    <td><?php echo $producto->getNombre(); ?></td>
                    <td><?php echo $producto->getDescripcion(); ?></td>
                    <?php if ($rol == Constants::$ROL_ADMIN){ ?>
                    <td><?php echo $producto->getCantidad(); ?></td>
                    <?php } ?>
                    <td><?php echo $producto->getPrecio(); ?>€</td>
                    <?php if ($rol == Constants::$ROL_ADMIN){ ?>
                    <td>
                        <form action="lista_p.php" method="post">
                            <input type="hidden" name="id_producto" value="<?php echo $producto->getId_producto();?>"/>
                            <input class="boton" type="submit" name="btn_borrar" value="Borrar">
                        </form>
                    </td>
                    <?php } ?>
                    <?php if ($rol == Constants::$ROL_USUARIO){ ?>
                    <td>
                        <form action="XXXXXXX">
                            <input class="boton" type="submit" value="Agregar al carrito">
                        </form>
                    </td>
                    <?php } ?>
                </tr>
                <?php 
                }
                ?>
            </tbody>
        </table>
    <?php 
        } else {
            ?><h2>No ha encontrado nada el buscador</h2><?php
        }
    }
    ?>
    </div>
</body>
</html>
