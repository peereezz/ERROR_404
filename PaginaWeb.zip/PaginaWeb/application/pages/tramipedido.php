<?php 
include_once '../persistente/MySQLPDO.class.php';
include_once '../entity/pedido.class.php';

$id_cliente = $_POST['id_cliente'];
$calle = $_POST['calle'];
$numero = $_POST['numero'];
$piso = $_POST['piso'];
$puerta = $_POST['puerta'];
$cp = $_POST['cp'];
$ciudad = $_POST['ciudad'];
$provincia = $_POST['provincia'];
$pais = $_POST['pais'];

$pedido = new pedido();

$pedido->setId_cliente($id_cliente);
$pedido->setCalle($calle);
$pedido->setNumero($numero);
$pedido->setPiso($piso);
$pedido->setPuerta($puerta);
$pedido->setCp($cp);
$pedido->setCiudad($ciudad);
$pedido->setProvincia($provincia);
$pedido->setPais($pais);

MySQLPDO::connect();

$resul = MySQLPDO::altaPedido($pedido);

if ($resul != 0){
    header("location: pago.php");
} else {
    echo "ERROR al tramitar el pedido";
}
?>