<?php 
include_once '../persistente/MySQLPDO.class.php';
include_once '../entity/usuario.class.php';

$nombre = $_POST["nombre"];
$descripcion = $_POST["descripcion"];
$cantidad = $_POST["cantidad"];
$precio = $_POST["precio"];

$producto = new producto();

$producto->setNombre($nombre);
$producto->setDescripcion($descripcion);
$producto->setCantidad($cantidad);
$producto->setPrecio($precio);

MySQLPDO::connect();

$resultado = MySQLPDO::altaProducto($producto);

if ($resultado != 0){
    header("location: lista_producto.php");
    exit();
} else {
    echo "ERROR";
}


?>