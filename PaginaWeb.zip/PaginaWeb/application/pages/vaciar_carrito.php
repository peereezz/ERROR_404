<?php
include_once '../persistente/MySQLPDO.class.php';
$id_cliente = $_POST['id_cliente'];

MySQLPDO::connect();
$resul = MySQLPDO::vaciarCarrito($id_cliente);

if ($resul != 0){
    header("location: carrito.php");
} else {
    echo "No se ha podido borrar";    
}
?>