<?php 
    include_once '../persistente/MySQLPDO.class.php';
    include_once '../utils/Constants.class.php';
    if (isset($_GET['id'])){
        $id_usu = $_GET['id'];
    } else if (isset($_POST['id'])) {
        $id_usu = $_POST['id'];
    } else {
        die ("ERROR: Se ha detectado un error en el sistema");
    }
    MySQLPDO::connect();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@500;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="../estilosweb/estilos2.css">
        <title>Error Sports</title>
    </head>
    <body>
        <div class="menu">
            <a href="inicio.php"><h1>Error Sports</h1></a>
            <ul>
                <li><a href="inicio.php">Inicio</a></li>
                <li><a href="lista_producto.php">Productos</a></li>
                <li><a href="lista_usuarios.php">Usuarios</a></li>
                <li><a href="alta_producto.php">Alta de Producto</a></li>
            </ul>
            <a href="../login.php"><img class="minilogin" src="../img/cuenta2.png" alt=""></a>
        </div>
        <div>
        <?php
            $resultado = null;
            $usuario = MySQLPDO::opUsuario($id_usu);
            if($usuario != null){
        ?>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <input type="hidden" name="id" value="<?php echo $usuario->getId(); ?>"><br><br>
            <input class="boton" type="text" name="nombre" value="<?php echo $usuario->getNombre();?>"><br><br>
            <input class="boton" type="text" name="apellido" value="<?php echo $usuario->getApellido();?>"><br><br>
            <input class="boton" type="text" name="email" value="<?php echo $usuario->getEmail();?>"><br><br>
            <input class="boton" type="number" name="telefono" value="<?php echo $usuario->getTelefono();?>"><br><br>
            <input class="boton" type="text" name="direccion" value="<?php echo $usuario->getDireccion();?>"><br><br>
            <input class="boton" type="text" name="usuario" value="<?php echo $usuario->getUsuario();?>"><br><br>
            <input class="boton" type="password" name="pass" value="<?php echo $usuario->getPassword();?>"><br><br>
            <input class="boton" type="text" name="rol" value="<?php echo $usuario->getRol();?>"><br><br>
            <input class="boton" type="submit" name="btn_modificar" value="Modificar">
        </form>
        <?php 
            if (isset($_POST['btn_modificar'])){

                $nombre = $_POST['nombre'];
                $apellido = $_POST['apellido'];
                $email = $_POST['email'];
                $telefono = $_POST['telefono'];
                $direccion = $_POST['direccion'];
                $usuario = $_POST['usuario'];
                $pass = $_POST['pass'];
                $rol = $_POST['rol'];
                $id = $_POST['id'];

                $clientes = new clientes();

                $clientes->setNombre(nombre: $nombre);
                $clientes->setApellido(apellido: $apellido);
                $clientes->setEmail(email: $email);
                $clientes->setTelefono(telefono: $telefono);
                $clientes->setDireccion(direccion: $direccion);
                $clientes->setUsuario(usuario: $usuario);
                $clientes->setPassword(password: $pass);
                $clientes->setRol($rol);
                $clientes->setId($id);

                $resultado = MySQLPDO::modificarUsuario($clientes);
                
                if ($resultado != 0) {
                    header("location: lista_usuarios.php");
                    exit();
                } else {
                    ?><p>ERROR: No se ha podido modificar</p><?php
                }
            }
        } else {
            echo "ERROR: El usuario que deseas modificar no existe";
        }
        ?>
        </div>
    </body>
</html>
