<?php
include_once '../persistente/MySQLPDO.class.php';
include_once '../entity/carrito.class.php';
include_once '../entity/usuario.class.php';

// Recibimos el ID del producto
$id_producto = $_POST['id_producto'];
$id_cliente = $_POST['id_cliente'];
$nombre = $_POST['nombre'];
$cantidad = $_POST['cantidad'];
$precio = $_POST['precio'];

MySQLPDO::connect();

$resultado = MySQLPDO::agregarACarrito($id_producto, $id_cliente, $nombre, $cantidad, $precio);

if ($resultado  != 0){
   header("location: carrito.php");
} else {
   echo "errorr";
}






//$carrito = new Carrito();
$carrito->setId($id /*recojo el idusuario del usuario de la sesion*/);
$carrito->addProducto($producto);

// creamos la sesion carrito, lo creamos
//session_start();

//$_SESSION['carrito'] = $carrito; 
//if ($carrito != null){
//   print_r($_SESSION['carrito']);
//}
?>