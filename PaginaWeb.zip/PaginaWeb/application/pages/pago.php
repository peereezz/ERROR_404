<?php
include_once '../persistente/MySQLPDO.class.php';
include_once '../entity/usuario.class.php';
include_once '../utils/Constants.class.php';
include_once '../entity/carrito.class.php';
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../login.php");
    exit;
}
$loginUsuario = $_SESSION['usuario'];
$rol = $loginUsuario->getRol();
?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../estilos2.css">
    <title>Error Sports</title>
</head>
<body>
    <div class="menu">
        <a href="inicio.php"><h1>Error Sports</h1></a>
        <ul>
            <?php if ($rol == Constants::$ROL_ADMIN){ ?>
            <li><a href="lista_usuarios.php">Usuarios</a></li>
            <li><a href="alta_producto.php">Alta de Producto</a></li>
            <?php } ?>
        </ul>
        <a href="logout.php"><img class="minilogin" src="../img/cuenta2.png" alt=""></a>
    </div>
    <?php
    $id = $loginUsuario->getId();
    MySQLPDO::connect();
    $resul = MySQLPDO::busCarrito($id);
    if (sizeof($resul)!= 0){
    ?>
    <h2>Vista previa del carrito</h2>
    <table class="carrito">
        <thead>
            <tr>
                <th>Producto</th>
                <th>Cantidad</th>
                <th>Precio</th>
            </tr>
        </thead>
        <tbody>
            <?php 
                $total = 0;
                foreach ($resul as $carro){
                $precio = $carro->getPrecio();
                $cantidad = $carro->getCantidad();

                $subtotal = $precio * $cantidad;
                $total += $subtotal;
            ?>
            <tr>
                <td><?php echo $carro->getNombre(); ?>
                <td><?php echo $carro->getCantidad(); ?></td>
                <td><?php echo $preci = $carro->getPrecio(); ?> €</td>
            </tr>
            <?php 
                }                
            ?>
            <tr>
                <td colspan="2">Total:</td>
                <td><?php echo $total;?> €</td>
            </tr>
        </tbody>
    </table>
    <?php 
    }
    ?>
    <form method="post" class="login" action="">
        <h2>Datos de la Trajeta</h2>
        <input class="boton" type="text" placeholder="Titular de la tarjeta" required><br><br>
        <input class="boton" type="number" placeholder="Numero de la tarjeta" required><br><br>
        <input class="boton" type="month" placeholder="Fecha de caducidad" required><br><br>
        <input class="boton" type="number" placeholder="CVV" required><br><br>
        <input class="boton" type="submit" name="btn_pago" value="Pagar">
    </form>
    <?php 
        if(isset($_POST['btn_pago'])){
            header('Location: inicio.php');
        }
    ?>
</body>
</html>