<?php 
include_once '../persistente/MySQLPDO.class.php';
include_once '../entity/usuario.class.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../estilosweb/estilos.css">
    <title>Error Sports</title>
</head>
<body>
    <div class="menu">
        <h1>Error Sports</h1>
        <ul>
            <li><a href="lista_usuarios.php">Lista de Usuarios</a></li>
            <li><a href="alta_producto.php">Alta de Producto</a></li>
            <li><a href="lista_producto.php">Productos</a></li>
        </ul>
        <a href="login.php"><img class="minilogin" src="../img/cuenta1.png" alt=""></a>
    </div>
    <?php 
        MySQLPDO::connect();
        $resultado = MySQLPDO::listausuarios();
    ?>
    <div>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Email</th>
                    <th>Telefono</th>
                    <th>Direccion</th>
                    <th>Usuario</th>
                    <th>Password</th>
                    <th>Borrar</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                foreach ($resultado as $clientes){
                ?>
                <tr>
                    <td><?php echo $clientes->getId(); ?></td>
                    <td><?php echo $clientes->getNombre(); ?></td>
                    <td><?php echo $clientes->getApellido(); ?></td>
                    <td><?php echo $clientes->getEmail(); ?></td>
                    <td><?php echo $clientes->getTelefono(); ?></td>
                    <td><?php echo $clientes->getDireccion(); ?></td>
                    <td><?php echo $clientes->getUsuario(); ?></td>
                    <td><?php echo $clientes->getPassword(); ?></td>
                    <td>
                        <form action="borrar_usuario.php" method="post">
                            <input type="hidden" name="id" value="<?php echo $clientes->getId();?>"/>
                            <input class="boton" type="submit" name="btn_borrar" value="Eliminar">
                        </form>
                    </td>
                </tr>
                <?php 
                }
                ?>
            </tbody>
        </table>
    </div>
<body>
<html>