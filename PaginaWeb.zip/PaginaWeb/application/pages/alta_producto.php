<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../estilosweb/estilos.css">
    <title>Error Sports</title>
</head>
<body>
    <div class="menu">
        <h1>Error Sports</h1>
        <ul>
            <li><a href="lista_usuarios.php">Lista de Usuarios</a></li>
            <li><a href="alta_producto.php">Alta de Producto</a></li>
            <li><a href="lista_producto.php">Productos</a></li>
        </ul>
        <a href="login.php"><img class="minilogin" src="../img/cuenta1.png" alt=""></a>
    </div>
    <div>
        <form method="post" action="XXXXX">
            <h2>Alta de Producto</h2>
            <input class="boton" type="text" name="nombre" placeholder="Nombre" required><br><br>
            <input class="boton" type="text" name="descripcion" placeholder="Descripcion" required><br><br>
            <input class="boton" type="number" name="cantidad" placeholder="Cantidad" required><br><br>
            <input class="boton" type="number" name="precio" placeholder="Precio" required><br><br>
            <input class="boton" type="submit" value="Enviar">
        </form>
    </div>
</body>
</html>