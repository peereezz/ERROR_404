<?php
include_once '../persistente/MySQLPDO.class.php';
include_once '../entity/usuario.class.php';
include_once '../utils/Constants.class.php';
include_once '../entity/carrito.class.php';
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../login.php");
    exit;
}
$loginUsuario = $_SESSION['usuario'];
$rol = $loginUsuario->getRol();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../estilos2.css">
    <title>Error Sports</title>
</head>
<body>
    <div class="menu">
        <a href="inicio.php"><h1>Error Sports</h1></a>
        <ul>
            <li><a href="inicio.php">Inicio</a></li>
            <li><a href="lista_producto.php">Productos</a></li>
            <li><a href="carrito.php">Carrito</a></li>
            <?php if ($rol == Constants::$ROL_ADMIN){ ?>
            <li><a href="lista_usuarios.php">Usuarios</a></li>
            <li><a href="alta_producto.php">Alta de Producto</a></li>
            <?php } ?>
        </ul>
        <a href="logout.php"><img class="minilogin" src="../img/cuenta1.png" alt=""></a>
    </div>
    <div>   
        <form class="plogin" method="post" action="alta_p.php">
            <h2>Alta de Producto</h2>
            <input class="boton" type="text" name="nombre" placeholder="Nombre" required><br><br>
            <input class="boton" type="text" name="descripcion" placeholder="Descripcion" required><br><br>
            <input class="boton" type="number" name="cantidad" placeholder="Cantidad" required><br><br>
            <input class="boton" type="decimal" name="precio" placeholder="Precio" required><br><br>
            <input class="boton" type="submit" value="Registrar Producto">
        </form>
    </div>
</body>
</html>
