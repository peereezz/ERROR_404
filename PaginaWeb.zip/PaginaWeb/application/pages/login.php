<?php 
    include_once '../persistente/MySQLPDO.class.php';
    include_once '../entity/usuario.class.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../estilosweb/estilos.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <title>Error Sports</title>
</head>
<body>
    <div class="menu">
        <h1>Error Sports</h1>
        <ul>
            <li><a href="login.php">Iniciar Sesion</a></li>
            <li><a href="registrarse.php">Registrarse</a></li>
            <li><a href="contrasena_admin.php">Administrador</a></li>
        </ul>
        <a href="login.php"><img class="minilogin" src="../img/cuenta1.png" alt=""></a>
    </div>
    <div>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <h2>Inicio Sesion</h2>
            <input class="boton" type="text" name="usuario" placeholder="Usuario" required><br><br>
            <input class="boton" type="password" name="password" placeholder="Contraseña" required><br><br>
            <input class="boton" type="submit" value="Iniciar Sesion" name="btn_login"><br>
            <?php
                if (isset($_POST['btn_login'])) {
            
                    $usuario = $_POST['usuario'];
                    $password = $_POST['password'];

                    MySQLPDO::connect();
                    $loginUsuario = MySQLPDO::loginusu($usuario, $password);

                    if ($loginUsuario) {
                        header('Location: inicio.php');
                        exit(); // importante para detener la ejecución
                    } else {
                        ?>
                        <p class="p1">Usuario o contraseña incorrectos.</p>
                        <input type="button" class="boton" value="He olvidado mi contraseña">
                        <?php
                    }
                }
            ?>
        </form>
        <?php 
            if (isset($_GET['registrado']) && $_GET['registrado'] === 'true'): ?>
            <script>
                Swal.fire({
                title: '¡Registro exitoso!',
                text: 'Bienvenido a Error Sports',
                icon: 'success',
                confirmButtonText: 'Aceptar'
                });
            </script>
        <?php endif; ?>
    </div>
</body>
</html>