<?php 
    include_once '../persistente/MySQLPDO.class.php';
    include_once '../entity/usuario.class.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../estilos/estilos.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <title>Error Sports</title>
</head>
<body>
    <div class="menu">
        <a href="inicio.php"><h1>Error Sports</h1></a>
        <ul>
            <li><a href="inicio.php">Inicio</a></li>
            <li><a href=""></a></li>
        </ul>
        <a href="login.php"><img class="minilogin" src="../img/cuenta1.png" alt=""></a>
    </div>
    <div>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <input class="boton" type="text" name="usuario" placeholder="Usuario" required><br><br>
            <input class="boton" type="password" name="password" placeholder="Contraseña" required><br><br>
            <input class="boton" type="submit" value="Iniciar Sesion" name="btn_login"><br>
        </form>
        <form>
            <a href="registrarse.php"><input class="boton" type="button" value="Registrarse"></input></a>
            <?php
                if (isset($_POST['btn_login'])) {
            
                    $usuario = $_POST['usuario'];
                    $password = $_POST['password'];

                    MySQLPDO::connect();
                    $loginUsuario = MySQLPDO::loginusu($usuario, $password);

                    if ($loginUsuario) {
                        header('Location: catalogo.php');
                        exit(); // importante para detener la ejecución
                    } else {
                        echo '<p>Usuario o contraseña incorrectos.</p>';
                    }
                }
            ?>
        </form> 
        <?php 
            if (isset($_GET['registrado']) && $_GET['registrado'] === 'true'): ?>
            <script>
                Swal.fire({
                title: '¡Registro exitoso!',
                text: 'Bienvenido a Error Sports',
                icon: 'success',
                confirmButtonText: 'Aceptar'
                });
            </script>
        <?php endif; ?>
    </div>
</body>
</html>