<?php
include_once '../persistente/MySQLPDO.class.php';
include_once '../entity/usuario.class.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../estilosweb/estilos.css">
    <title>Error Sports</title>
</head>
    <body>
        <div class="menu">
            <a href="inicio.php"><h1>Error Sports</h1></a>
            <ul>
                <li><a href="inicio.php">Inicio</a></li>
                <li><a href="catalogo.php">Catalogo</a></li>
                <li><a href="cotraseña_admin.php">Administrador</a></li>
            </ul>
            <a href="login.php"><img class="minilogin" src="../img/cuenta1.png" alt=""></a>
        </div>
        <div>
            <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                <h2>Contraseña de Administrador</h2>
                <input class="boton" type="password" name="password" placeholder="Contraseña"><br><br>
                <input class="boton" type="submit" name="btn_buscar"><br><br>
            <?php
                if (isset($_POST['btn_buscar'])){
                $pass = $_POST['password'];
                if ($pass == 'Admin123'){   
                    header('Location: lista_usuarios.php');
                } else {
                    echo 'La contraseña es incorrecta';
                }
            }
            ?>
            </form>
        </div>
    </body>
</html>