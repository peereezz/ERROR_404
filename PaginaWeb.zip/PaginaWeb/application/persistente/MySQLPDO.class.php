<?php
include_once '/Web/PaginaWeb/application/entity/carrito.class.php';
include_once '/Web/PaginaWeb/application/entity/producto.class.php';
include_once '/Web/PaginaWeb/application/entity/usuario.class.php';

class MySQLPDO {
    private static $host = "10.11.0.44"; //o la IP del servidor de BBBDD remoto
    private static $database = "Error404sports";
    private static $username = "alain";
    private static $password = "alain1234";
    private static $base;
    
    public static function connect() {
        if (MySQLPDO::$base != null) {
            MySQLPDO::$base = null;
        }
        try {
            $dsn = "mysql:host=" . MySQLPDO::$host . ";dbname=" . MySQLPDO::$database;
            MySQLPDO::$base = new PDO($dsn, MySQLPDO::$username, MySQLPDO::$password);
            MySQLPDO::$base->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
            return MySQLPDO::$base;
        } catch (Exception $e) {
            die ("Error connecting: {$e->getMessage()}");
        }
    }
    
    //ejecuta sentencias INSERT, UPDATE y DELETE
    public static function exec($sql, $params) {
        $stmt = MySQLPDO::$base->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->rowCount();
        return $result; //devuelve el n� de filas afectadas por la sentencia
    }
    
    //ejecuta sentencias SELECT
    public static function select($sql, $params) {
        $stmt = MySQLPDO::$base->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetchAll();
        return $result; //devuelve el conjunto de datos de la consulta
    }

    //Registrar Usuario
    public static function registrarCliente($clientes){
    $sql = "INSERT INTO cliente (nombre, apellido, email, telefono, direccion, usuario, password, rol) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $params = array(
        $clientes->getNombre(),
        $clientes->getApellido(),
        $clientes->getEmail(),
        $clientes->getTelefono(),
        $clientes->getDireccion(),
        $clientes->getUsuario(),
        $clientes->getPassword(),
        $clientes->getRol()

    );
    $resultado = MySQLPDO::exec($sql, $params);
    return $resultado;
    }   

    //buscar usuario
    public static function loginusu($usuario, $password) {

        $sql = "SELECT * FROM cliente WHERE usuario = ? AND password = ?";
        $params = array($usuario, $password);
        $resultado = MySQLPDO::select($sql, $params);

        // Si encuentra un resultado, devuelve un objeto cliente
        if (sizeof($resultado) !=0) {
            extract($resultado[0]); // primer resultado
            $objUsuario = new clientes();
            $objUsuario->setId($id);
            $objUsuario->setUsuario($usuario);
            $objUsuario->setPassword($password);
            $objUsuario->setRol($rol);
            return $objUsuario;
        } else {
            // Si no encuentra nada, devuelve null
            return null;
        }
    }

    //lista usuarios
    public static function listausuarios(){

        $listausuario = array();
        $sql = "SELECT * FROM cliente";
        $params = array();
        $resultado = MySQLPDO::select($sql, $params);

        foreach ($resultado as $fila){
            extract($fila);
            $clientes = new clientes();
            $clientes->setId($id);
            $clientes->setNombre($nombre);
            $clientes->setApellido($apellido);
            $clientes->setEmail($email);
            $clientes->setTelefono($telefono);
            $clientes->setDireccion($direccion);
            $clientes->setUsuario($usuario);
            $clientes->setPassword($password);
            $clientes->setRol($rol);
            array_push($listausuario, $clientes);
        }
        return $listausuario;
    }

    //borrar usuario
    public static function borrarusuario($id){

        $sql = "DELETE FROM cliente WHERE id = ?";
        $params = array($id);

        $resultado = MySQLPDO::exec($sql, $params);

        return $resultado;
    }

    public static function altaProducto($producto){
        $sql = "INSERT INTO producto (nombre, descripcion, cantidad, precio) VALUES (?, ?, ?, ?)";
        $params = array(

            $producto->getNombre(),
            $producto->getDescripcion(),
            $producto->getCantidad(),
            $producto->getPrecio(),

        );
        $resultado = MySQLPDO::exec($sql, $params);
        return $resultado;
    }

    public static function altaPedido($pedido){
        $sql = "INSERT INTO pedido (id_cliente, calle, numero, piso, puerta, cp, ciudad, provincia, pais) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $params = array(
            $pedido->getId_cliente(),
            $pedido->getCalle(),
            $pedido->getNumero(),
            $pedido->getPiso(),
            $pedido->getPuerta(),
            $pedido->getCp(),
            $pedido->getCiudad(),
            $pedido->getProvincia(),
            $pedido->getPais(),
        );
        $resultado = MySQLPDO::exec($sql, $params);
        return $resultado;
    }

    public static function listaPrpducto($nombre){

        $lista = array();
        $sql = "SELECT * FROM producto WHERE nombre LIKE ?";
        $params = array("%$nombre%");
        $resultado = MySQLPDO::select($sql, $params);

        foreach ($resultado as $fila){
            extract($fila);
            $producto = new Producto();
            $producto->setId_producto($id_producto);
            $producto->setNombre($nombre);
            $producto->setDescripcion($descripcion);
            $producto->setCantidad($cantidad);
            $producto->setPrecio($precio);
            array_push($lista, $producto);
        }
        return $lista;
    }

    public static function productoBorrar($id_producto){

        $sql = "DELETE FROM producto WHERE id_producto = ?";
        $params = array($id_producto);

        $resultado = MySQLPDO::exec($sql, $params);
        return $resultado;
    }

    public static function opProducto($id_producto){

        $sql = "SELECT * FROM producto WHERE id_producto = ?";
        $params = array($id_producto);
        $resultado = MySQLPDO::select($sql, $params);

        if (sizeof($resultado) != 0) {
            extract($resultado[0]);
            $producto = new Producto;
            $producto->setId_producto($id_producto);
            $producto->setNombre($nombre);
            $producto->setDescripcion($descripcion);
            $producto->setCantidad($cantidad);
            $producto->setPrecio($precio);
            return $producto;
        } else {
            return null;
        }
    }

    public static function modificarProducto($producto){
        $sql = "UPDATE producto SET nombre = ?, descripcion = ?, cantidad = ?, precio = ? WHERE id_producto = ?";
        $params = array(
            $producto->getNombre(),
            $producto->getDescripcion(),
            $producto->getCantidad(),
            $producto->getPrecio(),
            $producto->getId_producto(),
        );
        $resultado = MySQLPDO::exec($sql, $params);
        return $resultado;
    }

    public static function opUsuario($id_usu){

        $sql = "SELECT * FROM cliente WHERE id = ?";
        $params = array($id_usu);
        $resultado = MySQLPDO::select($sql, $params);

        if (sizeof($resultado) != 0) {
            extract($resultado[0]);
            $clientes = new Clientes;
            $clientes->setId($id);
            $clientes->setNombre($nombre);
            $clientes->setApellido(apellido: $apellido);
            $clientes->setEmail(email: $email);
            $clientes->setTelefono(telefono: $telefono);
            $clientes->setDireccion(direccion: $direccion);
            $clientes->setUsuario(usuario: $usuario);
            $clientes->setPassword(password: $password);
            $clientes->setRol($rol);
            return $clientes;
        } else {
            return null;
        }
        
    }

    public static function modificarUsuario($clientes){

        $sql = "UPDATE cliente SET nombre = ?, apellido = ?, email = ?, telefono = ?, direccion = ?, usuario = ?, password = ?, rol = ? WHERE id = ?";
        $params = array(
            $clientes->getNombre(),
            $clientes->getApellido(),
            $clientes->getEmail(),
            $clientes->getTelefono(),
            $clientes->getDireccion(),
            $clientes->getUsuario(),
            $clientes->getPassword(),
            $clientes->getRol(),
            $clientes->getId(),
        );
        $resultado = MySQLPDO::exec($sql, $params);
        return $resultado;

    }

    public static function modiPass($cliente){

        $sql = "UPDATE cliente SET password = ? WHERE id = ?";
        $params = array(
            $cliente->getPassword(),
            $cliente->getId(),
        );
        $re = MySQLPDO::exec($sql, $params);
        return $re;
    }

    public static function agregarACarrito($id_producto, $id_cliente, $nombre, $cantidad, $precio){

        $sql = "INSERT INTO carrito (id_cliente, id_producto, nombre, cantidad, precio) VALUES (?, ?, ?, ?, ?)";
        $params = array(
            $id_cliente,
            $id_producto,
            $nombre,
            $cantidad,
            $precio
        );

        $result = MySQLPDO::exec($sql,$params);
        return $result;
    }

    public static function busCarrito($id){

        $listaCarro = array();
        $sql = "SELECT * FROM carrito WHERE id_cliente = ?";
        $params = array($id);
        $resultado = MySQLPDO::select($sql, $params);

        foreach ($resultado as $fila){
            extract($fila);
            $carro = new Carrito();
            $carro->setId_carrito($id_carrito);
            $carro->setNombre($nombre);
            $carro->setCantidad($cantidad);
            $carro->setPrecio($precio);
            array_push($listaCarro, $carro);
        }
        return $listaCarro;
    }

    public static function borrarcarrito($id){
        $sql = "DELETE FROM carrito WHERE id_carrito = ?";
        $params = array($id);
        $resul = MySQLPDO::exec($sql, $params);
        return $resul;
    }

    public static function vaciarCarrito($id_cliente){
        $sql = "DELETE FROM carrito WHERE id_cliente = ?";
        $params = array($id_cliente);
        $res = MySQLPDO::exec($sql,$params);
        return $res;
    }

    public static function sumaCanti($id_carrito){
        $sql = "UPDATE carrito SET cantidad = cantidad + 1 WHERE id_carrito = ?";
        $params = array($id_carrito);
        $res = MySQLPDO::exec($sql, $params);
        return $res;
    }
    public static function restaCanti($id_carrito){
        $sql = "UPDATE carrito SET cantidad = cantidad - 1 WHERE id_carrito = ?";
        $params = array($id_carrito);
        $res = MySQLPDO::exec($sql, $params);
        return $res;
    }
}
?>