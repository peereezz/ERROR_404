<?php
include_once '../entity/usuario.class.php';

class MySQLPDO {
    private static $host = "localhost"; //o la IP del servidor de BBBDD remoto
    private static $database = "pingpongdata";
    private static $username = "administrador";
    private static $password = "hola1234";
    private static $base;
    
    public static function connect() {
        if (MySQLPDO::$base != null) {
            MySQLPDO::$base = null;
        }
        try {
            $dsn = "mysql:host=" . MySQLPDO::$host . ";dbname=" . MySQLPDO::$database;
            MySQLPDO::$base = new PDO($dsn, MySQLPDO::$username, MySQLPDO::$password);
            MySQLPDO::$base->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
            return MySQLPDO::$base;
        } catch (Exception $e) {
            die ("Error connecting: {$e->getMessage()}");
        }
    }
    
    //ejecuta sentencias INSERT, UPDATE y DELETE
    public static function exec($sql, $params) {
        $stmt = MySQLPDO::$base->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->rowCount();
        return $result; //devuelve el n� de filas afectadas por la sentencia
    }
    
    //ejecuta sentencias SELECT
    public static function select($sql, $params) {
        $stmt = MySQLPDO::$base->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetchAll();
        return $result; //devuelve el conjunto de datos de la consulta
    }

    //Registrar Usuario
    public static function registrarCliente($clientes){
    $sql = "INSERT INTO cliente (nombre, apellido, email, telefono, direccion, usuario, password) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $params = array(
        $clientes->getNombre(),
        $clientes->getApellido(),
        $clientes->getEmail(),
        $clientes->getTelefono(),
        $clientes->getDireccion(),
        $clientes->getUsuario(),
        $clientes->getPassword()
    );
    $resultado = MySQLPDO::exec($sql, $params);
    return $resultado;
    }   

    //buscar usuario
    public static function loginusu($usuario, $password) {

        $sql = 'SELECT * FROM cliente WHERE usuario = ? AND password = ?';
        $params = array($usuario, $password);
        $resultado = MySQLPDO::select($sql, $params);

        // Si encuentra un resultado, devuelve un objeto cliente
        if (!empty($resultado)) {
            $fila = $resultado[0]; // primer resultado
            $objUsuario = new clientes();
            $objUsuario->setId($fila['Id']);
            $objUsuario->setUsuario($fila['usuario']);
            $objUsuario->setPassword($fila['password']);
            return $objUsuario;
        }
    // Si no encuentra nada, devuelve null
    return null;
    }
}
?>
