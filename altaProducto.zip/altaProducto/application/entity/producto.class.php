<?php
class Producto {
    
    private $numSerie;
    private $marca;
    private $categoria;
    private $nombreProducto;
    private $descripcion;
    /**
     * @return mixed
     */
    public function getNumSerie()
    {
        return $this->numSerie;
    }
    /**
     * @return mixed
     */
    public function getMarca()
    {
        return $this->marca;
    }
    /**
     * @return mixed
     */
    public function getCategoria()
    {
        return $this->categoria;
    }
    /**
     * @return mixed
     */
    public function getNombreProducto()
    {
        return $this->nombreProducto;
    }
    /**
     * @return mixed
     */
    public function getDescripcion()
    {
        return $this->descripcion;
    }
    /**
     * @param mixed $numSerie
     */
    public function setNumSerie($numSerie)
    {
        $this->numSerie = $numSerie;
    }
    /**
     * @param mixed $marca
     */
    public function setMarca($marca)
    {
        $this->marca = $marca;
    }
    /**
     * @param mixed $categoria
     */
    public function setCategoria($categoria)
    {
        $this->categoria = $categoria;
    }
    /**
     * @param mixed $nombreProducto
     */
    public function setNombreProducto($nombreProducto)
    {
        $this->nombreProducto = $nombreProducto;
    }
    /**
     * @param mixed $descripcion
     */
    public function setDescripcion($descripcion)
    {
        $this->descripcion = $descripcion;
    }
}
?>