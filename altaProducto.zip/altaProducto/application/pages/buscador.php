<?php 
include_once '../persistente/MySQLPDO.class.php';
include_once '../entity/producto.class.php';
?>
<html>
    <head>

    </head>
    <body>
        <h1>Buscar Producto</h1>
        <?php 
        //para qe se active a si mismo
        ?>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        Nombre: <input type="text" name="nombreProducto">
        <input type="submit" name="btn_buscar" value="buscar">
        </form>
        <?php 
        //comprobar que el boton se ha pulsado 
        if (isset($_POST['btn_buscar'])) {
            //creamos la variable
            $nombre = $_POST['nombreProducto'];
            //conectarse a la base de datos
            MySQLPDO::connect();
            //crear una variable llamando a la funcion
            $listaProducto = MySQLPDO::buscarProducto($nombre);
            //creando un IF diciendo que si es cero de  lo de abajo del todo
            if (sizeof($listaProducto) != 0) {
        ?>
        
        <table border="1">
            <thead>
                <tr>
                    <th>nomSerie</th>
                    <th>marca</th>
                    <th>categoria</th>
                    <th>nombreProducto</th>
                    <th>descripcion</th>
                </tr>
            </thead>
            <tbody>
            <?php 
                foreach ($listaProducto as $producto) {
            ?>
                <tr>
                    <td><?php echo $producto->getnumSerie() ?></td>
                    <td><?php echo $producto->getmarca() ?></td>
                    <td><?php echo $producto->getcategoria() ?></td>
                    <td><?php echo $producto->getnombreProducto() ?></td>
                    <td><?php echo $producto->getdescripcion() ?></td>
                </tr>
            <?php 
                }
            ?>    
            </tbody>
        </table>

        <?php 
            } else {
                echo "no hay resultado";
            }
        }
        ?>

    </body>
</html>