<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Alta de Producto</title>
    </head>
    <body>
        <h1>Alta Producto</h1>
        <form action="altaP.php" method="post">
        	
        	<label for="numSerie">Numero de serie: </label>
            <input type="text" name="numSerie"><br><br>
        
            <label for="marca">Marca: </label>
            <input type="text" name="marca"><br><br>
            
            <label for="categoria">Categoria: </label>
            <input type="text" name="categoria"><br><br>     

            <label for="nombreProducto">Nombre Producto: </label>
            <input type="text" name="nombreProducto"><br><br>

            <label for="descripcion">Descripcion: </label>
            <input type="text" name="descripcion"><br><br>

            <input type="submit" name="btn_alta_producto" value="Registrar">
        </form>
    </body>
</html>
