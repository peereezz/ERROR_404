<?php

include_once '../entity/producto.class.php';
include_once '../persistente/MySQLPDO.class.php';

    //Variables que cogen lo del formulario
    $numSerie = $_POST['numSerie'];
    $marca = $_POST['marca'];
    $categoria = $_POST['categoria'];
    $nombreProducto = $_POST['nombreProducto'];
    $descripcion = $_POST['descripcion'];
    
    //Creo un objeto de tipo Usuario
    $producto = new Producto();
    
    //Asigno valor a sus atributos
    $producto->setnumSerie($numSerie);
    $producto->setmarca($marca);
    $producto->setcategoria($categoria);
    $producto->setnombreProducto($nombreProducto);
    $producto->setdescripcion($descripcion);
    
    //conectarme a la base de DATOS. Poner SIEMPRE
    MySQLPDO::connect();
    
    //funcion de insertar usuario
    $resultado = MySQLPDO::insertarProducto($producto);
    
    if ($resultado != 0){
        echo "producto registrado";
    } else {
        echo "No se ha podido registrar";
    }
?>