<?php
include_once '../entity/Producto.class.php';

class MySQLPDO {
    private static $host = "localhost"; //o la IP del servidor de BBBDD remoto
    private static $database = "loginreto1"; //El nombre de la base de datos    
    private static $username = "user_login2025";//usuario de la base de datos
    private static $password = "login_user2025";// contraseña de la base de datos
    private static $base;
    
    public static function connect() {
        if (MySQLPDO::$base != null) {
            MySQLPDO::$base = null;
        }
        try {
            $dsn = "mysql:host=" . MySQLPDO::$host . ";dbname=" . MySQLPDO::$database;
            MySQLPDO::$base = new PDO($dsn, MySQLPDO::$username, MySQLPDO::$password);
            MySQLPDO::$base->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
            return MySQLPDO::$base;
        } catch (Exception $e) {
            die ("Error connecting: {$e->getMessage()}");
        }
    }
    
    //ejecuta sentencias INSERT, UPDATE y DELETE
    public static function exec($sql, $params) {
        $stmt = MySQLPDO::$base->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->rowCount();
        return $result; //devuelve el n� de filas afectadas por la sentencia
    }
    
    //ejecuta sentencias SELECT
    public static function select($sql, $params) {
        $stmt = MySQLPDO::$base->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetchAll();
        return $result; //devuelve el conjunto de datos de la consulta
    }
    
    //Crear la funcion INSERT
    public static function insertarProducto($producto) {
        //llamando al INSERT
        $sql = "INSERT INTO producto (numSerie, marca, categoria, nombreProducto, descripcion) VALUES (?, ?, ?, ?, ?)";
        //meter los valores de ?,?,?,?,? en el params
        $params = array(
            $producto->getnumSerie(),
            $producto->getmarca(),
            $producto->getcategoria(),
            $producto->getnombreProducto(),
            $producto->getdescripcion()
        );
        //para guardar en resultado
        $resultado = MySQLPDO::exec($sql, $params);
        //devuelvo el resultado
        return $resultado;
    }
    //crear la funcion busacar = SELECT
    public static function buscarProducto($nombre) {
        //creo un array que es el que voy a devolver
        $listaProducto = array();
        //hacer la SELECT
        $sql = "SELECT * FROM producto WHERE nombreProducto LIKE ?";
        //para coger el nombre de la variable del BUSCADOR
        $params = array("%$nombre%");
        //ejecuto la select
        $resultado = MySQLPDO::select($sql, $params);
        
        foreach ($resultado as $fila){
            extract($fila); //crea variables automaticamente con los nombre de las columnas de la base de datos
            $producto = new Producto();
            $producto->setNumSerie($numSerie);
            $producto->setMarca($marca);
            $producto->setCategoria($categoria);
            $producto->setNombreProducto($nombreProducto);
            $producto->setDescripcion($descripcion);
            array_push($listaProducto, $producto);
        }
        return $listaProducto;
    }
}
?>